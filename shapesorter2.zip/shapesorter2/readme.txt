great thanks to Alan Gray:

agray3.github.io/2016/11/29/Demystifying-Data-Input-to-TensorFlow-for-Deep-Learning.html


Run the project as is for linear model and for CNN
Then paste your own data and run again.
